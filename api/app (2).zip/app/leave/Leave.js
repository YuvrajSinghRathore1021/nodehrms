const express = require("express");
const router = express.Router();
const db = require("../../../DB/ConnectionSql");

///////// leaveapi.js///////////////
router.post("/fetchleave", (req, res) => {
    const { userData } = req.body;
    let decodedUserData = null;

    if (userData) {
        try {
            const decodedString = Buffer.from(userData, "base64").toString("utf-8");
            decodedUserData = JSON.parse(decodedString);
        } catch (error) {
            console.error("Error decoding userData:", error);
            return res
                .status(400)
                .json({ status: false, error: "Invalid userData format" });
        }
    }

    if (!decodedUserData) {
        return res
            .status(400)
            .json({ status: false, error: "User data is required" });
    }

    const { id } = decodedUserData;
    const limit = parseInt(req.body.limit, 10) || 10;
    const page = parseInt(req.body.page, 10) || 1;
    const offset = (page - 1) * limit;

    // Fetch the reporting manager of the employee (if required)
    const query = `SELECT reporting_manager FROM employees WHERE  employee_status=1 and status=1 and delete_status=0 and id = ? `;
    const queryParams = [id];

    db.query(query, queryParams, (err, result) => {
        if (err) {
            console.error("Error fetching reporting manager:", err);
            return res
                .status(500)
                .json({ status: false, error: "Error fetching reporting manager" });
        }
        if (!result || result.length === 0) {
            return res
                .status(404)
                .json({ status: false, error: "Employee not found" });
        }
        const reportingManagerId = result[0].reporting_manager;
        // Fetch leave records based on the role and reporting manager
        let leaveQuery = `
      SELECT 
          e.employee_id, 
          e.first_name, 
          e.last_name,
          e.type, 
          e.reporting_manager,
          a.leave_type, 
          a.status, 
          a.leave_rule_id,
          a.start_date, 
          a.end_date, 
          a.leave_id,
          DATEDIFF(a.end_date, a.start_date) + 1 AS leave_days
      FROM 
          employees e
      INNER JOIN 
          leaves a ON e.id = a.employee_id
      WHERE 
           e.employee_status=1 and e.status=1 and e.delete_status=0 and a.deletestatus = 0
    `;
        let leaveQueryParams = [];
        leaveQuery += ` AND a.employee_id = ?`;
        leaveQueryParams.push(id);

        leaveQuery += ` LIMIT ? OFFSET ?`;
        leaveQueryParams.push(limit, offset);

        db.query(leaveQuery, leaveQueryParams, (err, results) => {
            if (err) {
                console.error("Error fetching leave records:", err);
                return res
                    .status(500)
                    .json({ status: false, error: "Error fetching leave records" });
            }

            // Count query for pagination
            let countQuery = `
        SELECT 
            COUNT(a.leave_id) AS total 
        FROM 
            employees e 
        INNER JOIN 
            leaves a ON e.id = a.employee_id
        WHERE 
             e.employee_status=1 and e.status=1 and e.delete_status=0 and a.deletestatus = 0
      `;
            let countParams = [];

            countQuery += ` AND a.employee_id = ?`;
            countParams.push(id);

            db.query(countQuery, countParams, (err, countResults) => {
                if (err) {
                    console.error("Error counting leave records:", err);
                    return res
                        .status(500)
                        .json({ status: false, error: "Error counting leave records" });
                }

                const total = countResults[0]?.total || 0;
                const recordsWithSrnu = results.map((record, index) => ({
                    ...record
                }));

                // Send the response
                res.json({
                    status: true,
                    records: recordsWithSrnu,
                    total,
                    page,
                    limit
                });
            });
        });
    });
});



// new 
const decodeUserData = (userData) => {
    try {
      const decodedString = Buffer.from(userData, "base64").toString("utf-8");
      return JSON.parse(decodedString);
    } catch (error) {
      return null;
    }
  };

  
router.post("/api/leaveApprovalLog", async (req, res) => {
    try {
        let { EmployeeId, userData } = req.body;
        let decodedUserData = null;

        if (userData) {
            decodedUserData = decodeUserData(userData);
            if (!decodedUserData || !decodedUserData.id || !decodedUserData.company_id) {
                return res
                    .status(400)
                    .json({
                        status: false,
                        message: "Invalid userData",
                        error: "Invalid userData"
                    });
            }
        } else {
            return res
                .status(400)
                .json({
                    status: false,
                    message: "userData is required",
                    error: "Missing userData"
                });
        }

        // Parse filters

        EmployeeId = EmployeeId || decodedUserData.id;

        // Query to fetch attendance requests
        const query = `
     SELECT 
        l.leave_id,
        l.employee_id, 
        l.company_id, 
        l.rm_status, 
        l.rm_id, 
        l.rm_remark, 
        l.admin_id, 
        l.admin_status, 
        l.admin_remark,   
        l.status, 
        l.reason, 
        l.created,
  
      l.leave_type,  
             l.start_date, 
             l.end_date, 
            DATEDIFF( l.end_date,  l.start_date) + 1 AS leave_days,
  
          Emp.employee_id, 
            Emp.first_name, 
            Emp.last_name,
            Emp.type, 
            Emp.reporting_manager
    FROM 
        leaves AS l
    INNER JOIN 
        employees AS Emp 
        ON Emp.id = l.employee_id
    WHERE 
        l.employee_id = ? 
        AND (
            -- Case 1: Manager's requests
            l.rm_id = ? 
            -- Case 2: admin/CEO/HR with no RM assigned
            OR (
                EXISTS (
                    SELECT 1 
                    FROM employees 
                    WHERE 
                        id = ? 
                        AND company_id = ? 
                        AND FIND_IN_SET(type, 'admin,ceo,hr') > 0
                ) 
                AND l.rm_id = 0
            )
            
            -- Case 3: Admin/CEO/HR with RM assigned and approved
            OR (
                EXISTS (
                    SELECT 1 
                    FROM employees 
                    WHERE 
                        id = ? 
                        AND company_id = ? 
                        AND FIND_IN_SET(type, 'admin,ceo,hr') > 0
                ) 
                AND l.rm_id != 0 
                AND l.rm_status = 1
            )
        )
    ORDER BY 
        l.leave_id DESC;
  `;

        const queryParams = [
            EmployeeId,
            decodedUserData.id,
            decodedUserData.id,
            decodedUserData.company_id,
            decodedUserData.id,
            decodedUserData.company_id
        ];

        // Execute the query
        const [results] = await db.promise().query(query, queryParams);

        // Count total records for pagination
        const countQuery =
            "SELECT COUNT(leave_id) AS total FROM leaves WHERE 1 = 1";
        const [countResults] = await db.promise().query(countQuery);

        const total = countResults[0]?.total || 0;

        // Add serial number (srnu) to each result
        const requestsWithSrnu = results.map((request, index) => ({
            srnu: index + 1,
            ...request
        }));

        res.json({
            status: true,
            requests: requestsWithSrnu,
            total
        });
    } catch (err) {
        console.error("Error fetching attendance approval log:", err);
        res
            .status(500)
            .json({ status: false, error: "Server error", message: err.message });
    }
});

module.exports = router;
