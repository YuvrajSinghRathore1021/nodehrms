const express = require('express');
const router = express.Router();
const cors = require('cors');
const db = require('../../../DB/ConnectionSql');
router.use(cors());

router.post('/api/fetchDetails', (req, res) => {
    const { userData, type, UserId } = req.body;
    let decodedUserData = null;

    if (userData) {
        try {
            const decodedString = Buffer.from(userData, 'base64').toString('utf-8');
            decodedUserData = JSON.parse(decodedString);
        } catch (error) {
            return res.status(400).json({ status: false, error: 'Invalid userData' });
        }
    }

    // Validate decoded userData
    if (!decodedUserData || !decodedUserData.id) {
        return res.status(400).json({ status: false, error: 'Employee ID is required' });
    }
    let EmpID = UserId || decodedUserData.id;

    let query;
    let queryParams = '';

    queryParams = [EmpID];

    if (type === 'Personal') {

        query = `SELECT id, first_name, last_name, blood_group, dob, marital_status, gender,
                         official_email_id, email_id, contact_number, emergency_contact_name,
                         current_address, permanent_address, social_profile_link 
                  FROM employees WHERE id = ?`;

    } else if (type === 'Work') {

        query = `SELECT e.id, e.date_of_Joining, e.work_location, e.employee_type, e.employee_id, 
       e.experience, e.probation_period, e.probation_status, e.job_title, e.designation, 
       d.name AS department_name, 
       sd.name AS sub_department_name
       ,e.department, 
       e.sub_department
FROM employees AS e 
LEFT JOIN departments AS d ON e.department = d.id
LEFT JOIN departments AS sd ON e .sub_department = sd.id
WHERE e.id = ?`;

    } else {
        return res.status(400).json({ error: 'Invalid type specified' });
    }

    // Execute the query
    db.query(query, queryParams, (err, results) => {
        if (err) {
            console.error('Error fetching data:', err);
            return res.status(500).json({ status: false, status: false, error: 'Server error' });
        }
        if (results.length === 0) {
            return res.status(404).json({ status: false, error: 'No data found' });
        }

        let query = "SELECT instagram, facebook, linkedin FROM social_profile WHERE company_id = ? AND employee_id = ? AND type=? And delete_status=0";
        let dataArray = [decodedUserData.company_id, EmpID, "Employee_Profile"];

        db.query(query, dataArray, (err, results1) => {
            if (err) {
                return res.status(500).json({ status: false, message: 'Database error.', error: err });
            }
            res.json({
                data: results[0],
                SocialProfileData: results1,
                status: true,
                message: 'Data found'
            });
        });

    });
});




// Export the router
module.exports = router;
